Meteor.methods({
    saveUserInfo: function(args) {
        Meteor.users.update(args.select, {
            $set: {
                point: args.fields.point,
                balance: args.fields.balance,
                isadmin: args.fields.isadmin
            },
        });

    },
});