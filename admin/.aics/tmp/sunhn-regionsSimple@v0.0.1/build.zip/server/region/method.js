Meteor.methods({
    uploadregionThumb: function(args) {
        var region = Regions.findOne({
            _id: args._id
        });
        upload(region.thumb, function(data) {
            Regions.update({
                _id: args._id
            }, {
                $set: {
                    "thumb": data
                }
            });
        }, function(e) {
            throw e;
        });
    }

});