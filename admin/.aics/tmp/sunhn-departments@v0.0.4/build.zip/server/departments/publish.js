Meteor.publish("departments",function(args){
	return Departments.find();
});