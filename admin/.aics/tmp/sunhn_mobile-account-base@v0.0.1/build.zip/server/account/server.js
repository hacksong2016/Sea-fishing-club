
Meteor.startup(function() {
    
    facc.sms.account = "Fmxx888";
    facc.sms.pwd = "fami@2014";
    facc.insert = function(err, id) {

    }

});
