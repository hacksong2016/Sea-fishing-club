Meteor.startup(function() {
   navigations.add("titles","职称管理","/titles","thumbs-o-up");
});

FlowRouter.route('/titles', {
  action: function(params, queryParams) {
    FlowLayout.render('layout', { content: "titles"});
  }
});

Template.titles.onCreated(function() {
    navigations.focus("titles");
    this.subscribe("titles");
});

Template.titles.helpers({

});

Template.titles.events({
    "click #update": function(event) {
        var obj = {
            "name": $("#e-name").val(),
            "status": $("#e-status").val()*1,
            "orderBy": $("#e-orderBy").val()*1,
        };
        
        Titles.update({
            _id: $("#editFor").val()
        }, {
            $set: obj
        });
        $("#edit").hide();
    },
     "click #createLink": function() {
        $("#create").show();
    },
    "click #save": function() {
        var obj = {
            "name": $("#c-name").val(),
            "status": $("#c-status").val()*1,
            "orderBy": $("#c-orderBy").val()*1,
            "createAt":new Date(),
        };

        Titles.insert(obj);

        $("#create").hide();

    },
});



Template.titles.onRendered(function() {
    var grid = $("#datagrid").ligerGrid({
        columns: [{
            display: 'Id',
            name: '_id',
        },{    
            display: '科室／部门名称',
            name: 'name',
            width:100,
            sort:false,
        },{    
            display: '排序',
            name: 'orderBy',
            width:100,
            sort:true,
        },{
            display: '创建时间',
            sort:true,
            width:120,
            render: function(r) {return format(r.createAt);}
        },{
            display: '状态',
            render: function(r) {return r.status == 1 ? "已上线":"未上线";}
        }, {
            display: ' ',
            render: function(r) {return "<a onclick='editInfo(\"" + r._id + "\")'>详细</a>";}
        }],
        dataAction:"local",
        allowAdjustColWidth:true,
        height:"100%",
        pageSize: 30,
        pageSizeOptions: [30, 60, 100, 200],
        
        rownumbers: true,

    });

    Tracker.autorun(function() {
        var jsonObj = {};

        jsonObj.Rows = Titles.find({}).fetch();
        // console.log(jsonObj.Rows);
        grid.set({
            data: jsonObj
        });
    });

    editInfo = function(id) {
        var obj = Titles.findOne({
            _id: id
        });
        
        $("#editFor").val(id);
        $("#e-name").val(obj.name);
        $("#e-orderBy").val(obj.orderBy);
        $("#e-status").val(obj.status);

        $("#edit").show();
    }

});
