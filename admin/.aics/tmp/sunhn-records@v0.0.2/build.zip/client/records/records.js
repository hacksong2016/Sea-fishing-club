Meteor.startup(function() {
    navigations.add("records", "档案管理", "/records", "file");
});

FlowRouter.route('/records', {
    action: function(params, queryParams) {
        FlowLayout.render('layout', {
            content: "records"
        });
    }
});

Template.records.onCreated(function() {
    navigations.focus("records");
    this.subscribe("recordsTables");
    this.subscribe("records");
    this.subscribe("users");
});

Template.records.helpers({

});

Template.records.events({
    "click #update": function(event) {
        var obj = {
            "fullname": $("#e-fullname").val(),
            "year": $("#e-year").val() * 1,
            "tel": $("#e-tel").val(),
            "id": $("#e-id").val(),
            "history": $("#e-history").val(),
            "sex": $("#e-sex").val(),
        };

        Records.update({
            _id: $("#editFor").val()
        }, {
            $set: obj
        }, function() {

        });
        $("#edit").hide();
    },
    "click #createLink": function() {
        $("#create").show();
    },
    "click #save": function() {

        var obj = {
            "fullname": $("#c-fullname").val(),
            "year": $("#c-year").val() * 1,
            "tel": $("#c-tel").val(),
            "id": $("#c-id").val(),
            "history": $("#c-history").val(),
            "sex": $("#c-sex").val(),
            "createAt": new Date(),
        };


        Records.insert(obj);

        $("#create").hide();

    },
});



Template.records.onRendered(function() {
    var grid = $("#datagrid").ligerGrid({
        columns: [{
            display: 'Id',
            name: '_id',
        }, {
            display: '姓名',
            name: 'fullname',
        }, {
            display: '年龄',
            name: "year",
        }, {
            display: '手机号',
            name: 'tel',
        }, {
            display: '身份证ID',
            name: 'id',
        }, {
            display: '病史',
            name: 'history',
        }, {
            display: '创建时间',
            width: 120,
            render: function(r) {
                return format(r.createAt);
            }
        }, {
            display: '病例数量',
            render: function(r) {
                return RecordsTables.find({
                    record: r._id
                }).count();
            }
        }, {
            display: '性别',
            render: function(r) {
                return r.sex == "F" ? "男" : "女";
            }
        }, {
            display: ' ',
            render: function(r) {
                return "<a onclick='editInfo(\"" + r._id + "\")'>编辑</a>";
            }
        }, {
            display: ' ',
            render: function(r) {
                return "<a href='/records/manage?id=" + r._id + "'>管理</a>";
            }
        }, {
            display: ' ',
            render: function(r) {
                return r.userid ? "" : ("<a onclick='grant(\"" + r._id + "\")'>授权</a>");
            }
        }],
        dataAction: "local",
        allowAdjustColWidth: true,
        height: "100%",
        pageSize: 30,
        pageSizeOptions: [30, 60, 100, 200],

        rownumbers: true,

    });

    Tracker.autorun(function() {
        var jsonObj = {};

        jsonObj.Rows = Records.find({}).fetch();
        // console.log(jsonObj.Rows);
        grid.set({
            data: jsonObj
        });
    });

    editInfo = function(id) {
        var obj = Records.findOne({
            _id: id
        });

        $("#editFor").val(id);
        $("#e-fullname").val(obj.fullname);
        $("#e-year").val(obj.year);
        $("#e-tel").val(obj.tel);
        $("#e-id").val(obj.id);
        $("#e-sex").val(obj.sex);
        $("#e-history").val(obj.history);

        $("#edit").show();
    }

    grant = function(id) {
        var obj = Records.findOne({
            _id: id
        });
        if (!obj.userid) {
            var user = Meteor.users.findOne({tel:obj.tel});
            if(user){
                if(confirm("是否要将档案授权给:" + user.nickname)){
                     Records.update({
                        _id: obj._id
                    }, {
                        $set: {userid:user._id}
                    });
                }
            }else{
                alert("未找到相应用户，并未在系统中注册。");
            }
        }else{
            alert("档案已被认领");
        }
    }

});
