Meteor.publish("titles",function(args){
	return Titles.find();
});