FlowRouter.route('/records/manage', {
    action: function(params, queryParams) {
        FlowLayout.render('layout', {
            content: "recordManage"
        });
    }
});

Template.recordManage.onCreated(function() {
    navigations.focus("records");
    this.subscribe("recordsTables");
    this.subscribe("records");
    this.subscribe("users");
});

Template.recordManage.helpers({
    record:function(){
        
        return Records.findOne({
            _id: FlowRouter.getQueryParam("id")
        });
    }
});

Template.recordManage.events({
    "click #update": function(event) {

        var obj = {
            "doctor": $("#e-doctor").val(),
            "clinic": $("#e-clinic").val(),
            "date": $("#e-date").val(),
            "desc": $("#e-desc").val(),
            "userid": facc.user()._id
        };


        RecordsTables.update({
            _id: $("#editFor").val()
        }, {
            $set: obj
        });

        $("#edit").hide();
    },
    "click #createLink": function() {
        $("#create").show();
    },
    "click #save": function() {

        var obj = {
            "doctor": $("#c-doctor").val(),
            "clinic": $("#c-clinic").val(),
            "date": $("#c-date").val(),
            "desc": $("#c-desc").val(),
            "createAt": new Date(),
            "record": FlowRouter.getQueryParam("id"),
            "userid": facc.user()._id
        };


        RecordsTables.insert(obj);

        $("#create").hide();

    },
});



Template.recordManage.onRendered(function() {
    var grid = $("#datagrid").ligerGrid({
        columns: [{
            display: 'id',
            name: '_id',
        }, {
            display: '医生',
            name: 'doctor',
        }, {
            display: '诊所',
            name: "clinic",
        }, {
            display: '就诊日期',
            name: 'date',
        }, {
            display: '描述',
            name: 'desc',
        }, {
            display: '创建时间',
            width: 120,
            render: function(r) {
                return format(r.createAt);
            }
        },{
            display: '更新者',
            render: function(r) {

               if(r.userid){
                    var user = Meteor.users.findOne({_id:r.userid});
                   
                    return user ? user.nickname : "";
               }
            }
        }, {
            display: ' ',
            render: function(r) {
                return "<a onclick='editInfo(\"" + r._id + "\")'>编辑</a>";
            }
        }],
        dataAction: "local",
        allowAdjustColWidth: true,
        height: "100%",
        pageSize: 30,
        pageSizeOptions: [30, 60, 100, 200],

        rownumbers: true,

    });

    Tracker.autorun(function() {

        var jsonObj = {};

        jsonObj.Rows = RecordsTables.find({
            record: FlowRouter.getQueryParam("id")
        }, {
            sort: {
                createAt: -1
            }
        }).fetch();
        // console.log(jsonObj.Rows);
        grid.set({
            data: jsonObj
        });

    });

    editInfo = function(id) {
        var obj = RecordsTables.findOne({
            _id: id
        });

        $("#editFor").val(id);
        $("#e-doctor").val(obj.doctor);
        $("#e-clinic").val(obj.clinic);
        $("#e-date").val(obj.date);
        $("#e-desc").val(obj.desc);

        $("#edit").show();
    }



});
