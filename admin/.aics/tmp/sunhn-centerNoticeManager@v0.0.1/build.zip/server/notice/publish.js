Meteor.publish("notice",function(args){
	return Notices.find();
});