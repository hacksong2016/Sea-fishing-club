Meteor.methods({
    uploadNoticeThumb: function(args) {
        var notice = Notices.findOne({
            _id: args._id
        });
        upload(notice.thumb, function(data) {
            Notices.update({
                _id: args._id
            }, {
                $set: {
                    "thumb": data
                }
            });
        }, function(e) {
            throw e;
        });
    },

});