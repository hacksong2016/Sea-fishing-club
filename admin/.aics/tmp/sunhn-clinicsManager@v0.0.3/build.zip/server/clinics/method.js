Meteor.methods({
    uploadClinicThumb: function(args) {
        var obj = Clinics.findOne({
            _id: args._id
        });
        upload(obj.thumb, function(data) {
            Clinics.update({
                _id: args._id
            }, {
                $set: {
                    "thumb": data
                }
            });
        }, function(e) {
            throw e;
        });
    },

});