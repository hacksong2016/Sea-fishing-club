Meteor.publish("records",function(args){
	return Records.find();
});
Meteor.publish("recordsTables",function(args){
	return RecordsTables.find();
});