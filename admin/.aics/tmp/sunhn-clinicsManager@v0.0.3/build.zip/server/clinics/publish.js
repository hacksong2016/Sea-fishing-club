Meteor.publish("clinics",function(args){
	return Clinics.find();
});