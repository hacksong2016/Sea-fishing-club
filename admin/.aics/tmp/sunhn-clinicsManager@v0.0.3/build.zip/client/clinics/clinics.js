Meteor.startup(function() {
   navigations.add("clinics","诊所管理","/clinics","plus");
});

FlowRouter.route('/clinics', {
  action: function(params, queryParams) {
    FlowLayout.render('layout', { content: "clinics"});
  }
});

Template.clinics.onCreated(function() {
    navigations.focus("clinics");
    this.subscribe("clinics");
});

Template.clinics.helpers({

});

Template.clinics.events({
    "change .ff-file input": function(event) {
        var that = $(event.currentTarget);
        lrz(event.currentTarget.files[0], {
            width: 720
        }).then(function(rst) {
            that.parent().css({
                "background-image": "url(" + rst.base64 + ")"
            });
            that.attr("data-file", rst.base64);
        });
    },
    "click #update": function(event) {


        var obj = {
            "name": $("#e-name").val(),
            "index": $("#e-index").val()*1,
            "address": $("#e-address").val(),
            "status": $("#e-status").val()*1,
            "recommand": $("#e-recommand").val()*1,
            "orderBy": $("#e-orderBy").val()*1,
            "thumb": $("#e-picture").attr("data-file"),
        };
        
        Clinics.update({
            _id: $("#editFor").val()
        }, {
            $set: obj
        }, function() {
            if (obj.thumb.indexOf("base64") > -1) {
                Meteor.call("uploadClinicThumb", {
                    _id: $("#editFor").val()
                });
            }
        });
        $("#edit").hide();
    },
     "click #createLink": function() {
        $("#create").show();
    },
    "click #save": function() {
        var obj = {
            "name": $("#c-name").val(),
            "index": $("#c-index").val()*1,
            "address": $("#c-address").val(),
            "status": $("#c-status").val()*1,
            "recommand": $("#c-recommand").val()*1,
            "orderBy": $("#c-orderBy").val()*1,
            "createAt":new Date(),
            "thumb": $("#c-picture").attr("data-file"),
        };

        Clinics.insert(obj, function(err, id) {
            Meteor.call("uploadClinicThumb", {
                _id: id
            });
        });

        $("#create").hide();

    },
});



Template.clinics.onRendered(function() {
    var grid = $("#datagrid").ligerGrid({
        columns: [{
            display: 'Id',
            name: '_id',
        },{    
            display: '诊所名称',
            name: 'name',
            width:100,
            sort:false,
        },{
            display: '地址',
            sort:false,
            name:"address",
        },{    
            display: '排序',
            name: 'orderBy',
            width:100,
            sort:true,
        },{
            display: '创建时间',
            sort:true,
            width:120,
            render: function(r) {return format(r.createAt);}
        },{
            display: '推荐',
            render: function(r) {return r.recommand == 1 ? "是":"否";}
        }, {
            display: '首页',
            render: function(r) {return r.index == 1 ? "是":"否";}
        },{
            display: '状态',
            render: function(r) {return r.status == 1 ? "已核实":"未核实";}
        }, {
            display: ' ',
            render: function(r) {return "<a onclick='editInfo(\"" + r._id + "\")'>详细</a>";}
        }],
        dataAction:"local",
        allowAdjustColWidth:true,
        height:"100%",
        pageSize: 30,
        pageSizeOptions: [30, 60, 100, 200],
        
        rownumbers: true,

    });

    Tracker.autorun(function() {
        var jsonObj = {};

        jsonObj.Rows = Clinics.find({}).fetch();
        // console.log(jsonObj.Rows);
        grid.set({
            data: jsonObj
        });
    });

    editInfo = function(id) {
        var obj = Clinics.findOne({
            _id: id
        });
        
        $("#editFor").val(id);
        $("#e-recommand").val(obj.recommand);
        $("#e-index").val(obj.index);
        $("#e-name").val(obj.name);
        $("#e-status").val(obj.status);
        $("#e-address").val(obj.address);
        $("#e-orderBy").val(obj.orderBy);
        $("#e-picture").parent().css({"background-image":"url(" +obj.thumb+ ")"});
        $("#e-picture").attr("data-file", obj.thumb);

        $("#edit").show();
    }

});
