Meteor.startup(function() {
   navigations.add("booking","预约管理","/booking","book");
});

FlowRouter.route('/booking', {
  action: function(params, queryParams) {
    FlowLayout.render('layout', { content: "booking"});
  }
});

Template.booking.onCreated(function() {
    navigations.focus("booking");
    this.subscribe("booking");
    this.subscribe("users");
    this.subscribe("clinics");
    this.subscribe("dentists");
    this.subscribe("departments");
    this.subscribe("titles");
});

Template.booking.helpers({

});

Template.booking.events({
  
    "click #update": function(event) {


        var obj = {
            "status": $("#e-status").val(),
        };
        
        Bookings.update({
            _id: $("#editFor").val()
        }, {
            $set: obj
        }, function() {
           
        });
        $("#edit").hide();
    },
    
});



Template.booking.onRendered(function() {
    var grid = $("#datagrid").ligerGrid({
        columns: [{    
            display: '用户',
            render:function(r){
                var user = Meteor.users.findOne({_id:r.userid});
                return user ? user.nickname : "";
            }
        },{    
            display: '联系方式',
            width :120,
            render:function(r){
                var user = Meteor.users.findOne({_id:r.userid});
                return user ? user.tel : "";
            }
        },{    
            display: '预约诊所',
            render:function(r){
                var dentists = Dentists.findOne({
                    _id:r.dentist
                });
                return dentists ? dentists.clinic : "";
            }
        },{    
            display: '诊所地址',
            render:function(r){
                var dentists = Dentists.findOne({
                    _id:r.dentist
                });
                return dentists ? dentists.address : "";
            }
        },{    
            display: '医生',
            render:function(r){
                var dentists = Dentists.findOne({
                    _id:r.dentist
                });
                return dentists ? dentists.fullname : "";
            }
        },{    
            display: '预约时间',
            width :140,
            render:function(r){
                return format(r.bookingAt);
            }
        },{    
            display: '院方联系方式',
             width :120,
            render:function(r){
                var dentists = Dentists.findOne({
                    _id:r.dentist
                });
                if(dentists){
                     var user = Meteor.users.findOne({_id:dentists.userid});
                    return user ? user.tel : "";
                }
            }
        },{
            display: '创建时间',
            render: function(r) {return format(r.createAt);}
        },{
            display: '状态',
            render: function(r) {
                 if (r.status == "SUBMIT") {
                    return "待确认";
                } else if (r.status == "CHECKIN") {
                    return "已确认";
                } else if (r.status == "COMPLETED") {
                    return "已完成";
                }else if (r.status == "CANCEL") {
                    return "已取消";
                }
            }
        }, {
            display: ' ',
            render: function(r) {return "<a onclick='editInfo(\"" + r._id + "\")'>详细</a>";}
        }],
        dataAction:"local",
        allowAdjustColWidth:true,
        height:"100%",
        pageSize: 30,
        pageSizeOptions: [30, 60, 100, 200],
        
        rownumbers: true,

    });

    Tracker.autorun(function() {
        var jsonObj = {};

        jsonObj.Rows = Bookings.find({}).fetch();
        // console.log(jsonObj.Rows);
        grid.set({
            data: jsonObj
        });
    });

    editInfo = function(id) {
        var obj = Bookings.findOne({
            _id: id
        });
        
        $("#editFor").val(id);
        $("#e-status").val(obj.status);
        $("#edit").show();
    }

});
