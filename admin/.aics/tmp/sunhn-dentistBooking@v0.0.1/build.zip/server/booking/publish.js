Meteor.publish("booking",function(args){
	return Bookings.find();
});