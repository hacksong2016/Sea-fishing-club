Meteor.startup(function() {
   navigations.add("dentist","医生管理","/dentist","user");
});

FlowRouter.route('/dentist', {
  action: function(params, queryParams) {
    FlowLayout.render('layout', { content: "dentist"});
  }
});

Template.dentist.onCreated(function() {
    navigations.focus("dentist");
    this.subscribe("dentists");
    this.subscribe("departments");
    this.subscribe("titles");
});

Template.dentist.helpers({

});

Template.dentist.events({
    "click #update": function(event) {


        var obj = {
            "fullname": $("#e-fullname").val(),
            "index": $("#e-index").val()*1,
            "status": $("#e-status").val()*1,
            "auth": $("#e-auth").val()*1,
            "recommand": $("#e-recommand").val()*1,
        };
        
        Dentists.update({
            _id: $("#editFor").val()
        }, {
            $set: obj
        }, function() {
           
        });
        $("#edit").hide();
    },
     
});



Template.dentist.onRendered(function() {
    var grid = $("#datagrid").ligerGrid({
        columns: [{
            display: 'Id',
            name: '_id',
        },{    
            display: '真实姓名',
            name: 'fullname',
            width:100,
            sort:false,
        },{
            display: '诊所',
            sort:false,
            name:"clinic",
        },{    
            display: '部门',
            render:function(r){
                var dp = Departments.findOne({_id:r.department});
                if(dp){
                    return dp.name;
                }
            }
        },{    
            display: '职称',
            render:function(r){
                var tt = Titles.findOne({_id:r.title});
                if(tt){
                    return tt.name;
                }
            }
        },{
            display: '创建时间',
            sort:true,
            width:120,
            render: function(r) {return format(r.createAt);}
        },{
            display: '推荐',
            render: function(r) {return r.recommand == 1 ? "是":"否";}
        },{
            display: '认证标识',
            render: function(r) {return r.auth == 1 ? "是":"否";}
        }, {
            display: '首页',
            render: function(r) {return r.index == 1 ? "是":"否";}
        },{
            display: '状态',
            render: function(r) {return r.status == 1 ? "已核实":"未核实";}
        }, {
            display: ' ',
            render: function(r) {return "<a onclick='editInfo(\"" + r._id + "\")'>详细</a>";}
        }],
        dataAction:"local",
        allowAdjustColWidth:true,
        height:"100%",
        pageSize: 30,
        pageSizeOptions: [30, 60, 100, 200],
        
        rownumbers: true,

    });

    Tracker.autorun(function() {
        var jsonObj = {};

        jsonObj.Rows = Dentists.find({}).fetch();
        // console.log(jsonObj.Rows);
        grid.set({
            data: jsonObj
        });
    });

    editInfo = function(id) {
        var obj = Dentists.findOne({
            _id: id
        });
        
        $("#editFor").val(id);
        $("#e-recommand").val(obj.recommand);
        $("#e-index").val(obj.index);
        $("#e-fullname").val(obj.fullname);
        $("#e-auth").val(obj.auth);
        $("#e-status").val(obj.status);
        $("#e-picture").parent().css({"background-image":"url(" +obj.avatar+ ")"});
        $("#e-picture").attr("data-file", obj.avatar);

        $("#edit").show();
    }

});
